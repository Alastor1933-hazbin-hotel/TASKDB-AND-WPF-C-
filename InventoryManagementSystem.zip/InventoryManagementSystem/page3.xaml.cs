﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace InventoryManagementSystem
{
    public partial class page3 : Window
    {
        string connectionString = "Data Source=.; Initial Catalog=Inventory; User ID=sa; Password=123";
        int selectedNameId = 0;

        public page3()
        {
            InitializeComponent();
            update();
        }

        public void update()
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Product", sqlConnection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                read.ItemsSource = table.DefaultView;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("INSERT INTO Product (Product_name) VALUES (@name)", sqlConnection))
                    {
                        command.Parameters.AddWithValue("@name", tx.Text);
                        command.ExecuteNonQuery();
                    }
                    update();
                    tx.Text = "";
                    MessageBox.Show("Product added successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("خطأ: " + ex.Message);
                }
            }
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("DELETE FROM Product WHERE Product_id = @Product_id", sqlConnection))
                    {
                        command.Parameters.AddWithValue("@Product_id", selectedNameId);
                        command.ExecuteNonQuery();
                    }
                    update();
                    tx.Text = "";
                    MessageBox.Show("Product deleted successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("خطأ: " + ex.Message);
                }
            }
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                try
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("UPDATE Product SET Product_name = @Product_name WHERE Product_id = @Product_id", sqlConnection))
                    {
                        command.Parameters.AddWithValue("@Product_id", selectedNameId);
                        command.Parameters.AddWithValue("@Product_name", tx.Text);
                        command.ExecuteNonQuery();
                    }
                    update();
                    tx.Text = "";
                    MessageBox.Show("Product updated successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("خطأ: " + ex.Message);
                }
            }
        }

        private void read_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (read.SelectedItem != null)
            {
                DataRowView row = (DataRowView)read.SelectedItem;
                selectedNameId = Convert.ToInt32(row["Product_id"]);
                tx.Text = row["Product_name"].ToString();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM order_list", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                read.ItemsSource = table.DefaultView;
            }
            back.Visibility = Visibility.Visible;
        }


        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            update();
            back.Visibility = Visibility.Collapsed;
        }
    }
}