﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace InventoryManagementSystem
{
    public partial class page2 : Window
    {
        string connectionString = "Data Source=.; Initial Catalog=Inventory; User ID=sa; Password=123";
        int selectedNameId = 0;
        string nameProduct = "";

        public page2()
        {
            InitializeComponent();
            view_data();
        }

        private void view_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (view.SelectedItem != null)
            {
                DataRowView row = (DataRowView)view.SelectedItem;
                selectedNameId = Convert.ToInt32(row["Product_id"]);
                nameProduct = row["Product_name"].ToString();
            }
        }

        public void view_data()
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Product", sqlConnection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                view.ItemsSource = table.DefaultView;
            }
        }

        private void buy_Click(object sender, RoutedEventArgs e)
        {
            if (selectedNameId == 0)
            {
                MessageBox.Show("يرجى اختيار منتج للشراء.");
                return;
            }

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                try
                {
                    sqlConnection.Open();

                    // تحقق أولاً من وجود أي طلبات مرتبطة بالمنتج
                    using (SqlCommand checkOrdersCmd = new SqlCommand("SELECT COUNT(*) FROM order_list WHERE Product_id = @Product_id", sqlConnection))
                    {
                        checkOrdersCmd.Parameters.AddWithValue("@Product_id", selectedNameId);
                        int ordersCount = (int)checkOrdersCmd.ExecuteScalar();

                        if (ordersCount > 0)
                        {
                            MessageBox.Show($"لا يمكن حذف المنتج '{nameProduct}' لأنه مرتبط بطلبات موجودة في نظام الجرد.");
                            return;
                        }
                    }

                    // حذف المنتج من جدول Product
                    using (SqlCommand deleteProductCmd = new SqlCommand("DELETE FROM Product WHERE Product_id = @Product_id", sqlConnection))
                    {
                        deleteProductCmd.Parameters.AddWithValue("@Product_id", selectedNameId);
                        int rowsAffected = deleteProductCmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"تم حذف المنتج '{nameProduct}' بنجاح.");
                        }
                        else
                        {
                            MessageBox.Show("لم يتم العثور على المنتج المحدد.");
                        }
                    }

                    view_data();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("خطأ: " + ex.Message);
                }
            }
        }
        }

    
}